"""Structural duplicate finder for Python projects."""

from .dry import Candidate, DuplicateGroup, Location, Options, find_duplicates, format_json, format_text, parse_args

__all__ = [
    "Candidate",
    "DuplicateGroup",
    "Location",
    "Options",
    "find_duplicates",
    "format_json",
    "format_text",
    "parse_args",
]
