from __future__ import annotations

import ast
import fnmatch
import io
import json
import os
import re
import tokenize
from dataclasses import asdict, dataclass, field
from typing import Any, Callable, Iterable, Sequence


@dataclass
class Options:
    paths: list[str] = field(default_factory=lambda: ["."])
    threshold: float = 0.82
    min_lines: int = 4
    min_nodes: int = 20
    format: str = "text"
    exclude: list[str] = field(default_factory=list)
    help: bool = False


@dataclass(frozen=True)
class Location:
    file: str
    start_line: int
    end_line: int
    qualname: str = ""


@dataclass(frozen=True)
class Candidate:
    score: float
    left: Location
    right: Location
    left_nodes: int
    right_nodes: int


@dataclass(frozen=True)
class DuplicateGroup:
    score: float
    locations: tuple[Location, ...]
    pairs: int


@dataclass(frozen=True)
class _Entry:
    file: str
    start_line: int
    end_line: int
    qualname: str
    nodes: int
    fingerprints: frozenset[str]


@dataclass(frozen=True)
class _Node:
    tag: str
    children: tuple[_Node, ...] = ()


@dataclass(frozen=True)
class _Pragmas:
    file_ignore: bool
    ignore_lines: frozenset[int]


USAGE = """Usage: dry4python [options] [file-or-directory ...]

Options:
  --threshold N   Minimum structural similarity score, default 0.82
  --min-lines N   Minimum source lines in a candidate function, default 4
  --min-nodes N   Minimum normalized syntax nodes, default 20
  --format F      text or json, default text
  --exclude GLOB  Exclude paths matching GLOB; can be repeated
  --json          Same as --format json
  --text          Same as --format text"""

_DEFAULT_EXCLUDE_PATTERNS = (
    "migrations/*",
    "*/migrations/*",
    "*_pb2.py",
    "*_pb2_grpc.py",
    "*_generated.py",
)

_SKIP_DIRS = {
    ".git",
    ".hg",
    ".mypy_cache",
    ".pytest_cache",
    ".ruff_cache",
    ".tox",
    ".venv",
    ".eggs",
    "__pycache__",
    "__pypackages__",
    "build",
    "dist",
    "htmlcov",
    "migrations",
    "site-packages",
    "target",
    "venv",
}

_CAMEL_BOUNDARY = re.compile(r"(?<=[a-z0-9])(?=[A-Z])")
_DRY4PYTHON_PRAGMA = re.compile(r"#\s*dry4python:\s*([^\s#]+)")


def parse_args(args: Sequence[str] | None) -> Options:
    args = [] if args is None else list(args)
    if "--help" in args or "-h" in args:
        return Options(paths=[], help=True)

    options = _load_pyproject_options(os.getcwd())
    cli_paths: list[str] = []
    i = 0
    while i < len(args):
        arg = args[i]
        if arg in ("--threshold", "--min-lines", "--min-nodes", "--format", "--exclude"):
            if i + 1 >= len(args):
                raise ValueError(f"missing value for {arg}")
            i += 1
            _apply_value_option(options, arg, args[i])
        elif arg == "--json":
            options.format = "json"
        elif arg == "--text":
            options.format = "text"
        else:
            if arg.startswith("--"):
                raise ValueError(f"unknown option: {arg}")
            cli_paths.append(arg)
        i += 1

    if cli_paths:
        options.paths = cli_paths
    if not options.paths:
        options.paths = ["."]
    return options


def find_duplicates(options: Options) -> list[Candidate]:
    paths = options.paths or ["."]
    entries = _scan_paths(paths, options.min_lines, options.min_nodes, options.exclude)
    candidates: list[Candidate] = []

    for i, left in enumerate(entries):
        for right in entries[i + 1 :]:
            score = _similarity(left, right)
            if score >= options.threshold:
                candidates.append(
                    Candidate(
                        score=score,
                        left=_location(left),
                        right=_location(right),
                        left_nodes=left.nodes,
                        right_nodes=right.nodes,
                    )
                )

    candidates.sort(
        key=lambda candidate: (
            -candidate.score,
            candidate.left.file,
            candidate.left.start_line,
            candidate.right.file,
            candidate.right.start_line,
        )
    )
    return candidates


def format_text(candidates: Sequence[Candidate]) -> str:
    if not candidates:
        return "No duplicate candidates found.\n"

    blocks: list[str] = []
    for group in _duplicate_groups(candidates):
        if len(group.locations) == 2:
            blocks.append(
                f"DUPLICATE score={group.score:.2f}\n"
                f"  {_line_range(group.locations[0])}\n"
                f"  {_line_range(group.locations[1])}"
            )
        else:
            lines = [f"DUPLICATE GROUP score={group.score:.2f} pairs={group.pairs}"]
            lines.extend(f"  {_line_range(location)}" for location in group.locations)
            blocks.append("\n".join(lines))
    return "\n\n".join(blocks) + "\n"


def format_json(candidates: Sequence[Candidate]) -> str:
    return json.dumps(
        {
            "candidates": [asdict(candidate) for candidate in candidates],
            "groups": [asdict(group) for group in _duplicate_groups(candidates)],
        },
        indent=2,
    ) + "\n"


def _duplicate_groups(candidates: Sequence[Candidate]) -> list[DuplicateGroup]:
    parents: list[int] = []
    locations: list[Location] = []
    indexes: dict[Location, int] = {}

    def index(location: Location) -> int:
        if location in indexes:
            return indexes[location]
        indexes[location] = len(locations)
        locations.append(location)
        parents.append(len(parents))
        return indexes[location]

    def find(i: int) -> int:
        while parents[i] != i:
            parents[i] = parents[parents[i]]
            i = parents[i]
        return i

    def union(left: int, right: int) -> None:
        left_root = find(left)
        right_root = find(right)
        if left_root != right_root:
            parents[right_root] = left_root

    for candidate in candidates:
        union(index(candidate.left), index(candidate.right))

    component_locations: dict[int, list[Location]] = {}
    for location, i in indexes.items():
        component_locations.setdefault(find(i), []).append(location)

    component_pairs: dict[int, int] = {root: 0 for root in component_locations}
    component_scores: dict[int, float] = {root: 0.0 for root in component_locations}
    for candidate in candidates:
        root = find(indexes[candidate.left])
        component_pairs[root] += 1
        component_scores[root] = max(component_scores[root], candidate.score)

    groups = [
        DuplicateGroup(
            score=component_scores[root],
            locations=tuple(sorted(group_locations, key=_location_sort_key)),
            pairs=component_pairs[root],
        )
        for root, group_locations in component_locations.items()
    ]
    groups.sort(key=_group_sort_key)
    return groups


def _group_sort_key(group: DuplicateGroup) -> tuple[float, str, int, int, str]:
    first = group.locations[0]
    return (-group.score, first.file, first.start_line, first.end_line, first.qualname)


def _location_sort_key(location: Location) -> tuple[str, int, int, str]:
    return location.file, location.start_line, location.end_line, location.qualname


def _apply_value_option(options: Options, arg: str, value: str) -> None:
    if arg == "--threshold":
        options.threshold = float(value)
    elif arg == "--min-lines":
        options.min_lines = int(value)
    elif arg == "--min-nodes":
        options.min_nodes = int(value)
    elif arg == "--format":
        if value not in {"text", "json"}:
            raise ValueError(f"unknown format: {value}")
        options.format = value
    elif arg == "--exclude":
        options.exclude.append(value)


def _load_pyproject_options(start_dir: str) -> Options:
    options = Options(paths=[])
    pyproject = _find_pyproject(start_dir)
    if pyproject is None:
        return options

    data = _read_toml(pyproject)
    tool = data.get("tool", {})
    if not isinstance(tool, dict):
        return options
    config = tool.get("dry4python", {})
    if not isinstance(config, dict):
        return options

    for key, value in config.items():
        _apply_config_value(options, key, value)
    if options.paths:
        options.paths = [_resolve_config_path(path, os.path.dirname(pyproject), start_dir) for path in options.paths]
    return options


def _resolve_config_path(path: str, config_dir: str, cwd: str) -> str:
    if os.path.isabs(path):
        return path
    absolute = os.path.join(config_dir, path)
    return _to_slash(os.path.relpath(absolute, cwd))


def _find_pyproject(start_dir: str) -> str | None:
    current = os.path.abspath(start_dir)
    while True:
        candidate = os.path.join(current, "pyproject.toml")
        if os.path.isfile(candidate):
            return candidate
        parent = os.path.dirname(current)
        if parent == current:
            return None
        current = parent


def _read_toml(path: str) -> dict[str, Any]:
    try:
        import tomllib
    except ModuleNotFoundError:
        try:
            import tomli as tomllib
        except ModuleNotFoundError:
            return _read_dry4python_toml_fallback(path)

    with open(path, "rb") as file:
        return tomllib.load(file)


def _read_dry4python_toml_fallback(path: str) -> dict[str, Any]:
    config: dict[str, Any] = {}
    in_section = False
    with open(path, encoding="utf-8") as file:
        for raw_line in file:
            line = raw_line.strip()
            if not line or line.startswith("#"):
                continue
            if line.startswith("[") and line.endswith("]"):
                in_section = line == "[tool.dry4python]"
                continue
            if not in_section or "=" not in line:
                continue
            key, raw_value = line.split("=", 1)
            key = key.strip().strip('"\'')
            config[key] = _parse_toml_value(raw_value.split("#", 1)[0].strip())
    return {"tool": {"dry4python": config}}


def _parse_toml_value(raw_value: str) -> Any:
    try:
        return ast.literal_eval(raw_value)
    except (SyntaxError, ValueError):
        pass
    try:
        return int(raw_value)
    except ValueError:
        pass
    try:
        return float(raw_value)
    except ValueError:
        return raw_value.strip('"\'')


def _apply_config_value(options: Options, key: str, value: Any) -> None:
    normalized = key.replace("-", "_")
    if normalized == "threshold":
        options.threshold = float(value)
    elif normalized == "min_lines":
        options.min_lines = int(value)
    elif normalized == "min_nodes":
        options.min_nodes = int(value)
    elif normalized == "format":
        if value not in {"text", "json"}:
            raise ValueError(f"unknown format: {value}")
        options.format = str(value)
    elif normalized == "paths":
        options.paths = _string_list(value, "paths")
    elif normalized in {"exclude", "excludes"}:
        options.exclude.extend(_string_list(value, normalized))


def _string_list(value: Any, key: str) -> list[str]:
    if isinstance(value, str):
        return [value]
    if isinstance(value, list) and all(isinstance(item, str) for item in value):
        return list(value)
    raise ValueError(f"{key} must be a string or list of strings")


def _scan_paths(paths: Sequence[str], min_lines: int, min_nodes: int, exclude_patterns: Sequence[str]) -> list[_Entry]:
    entries: list[_Entry] = []
    for file in _files_for_paths(paths, exclude_patterns):
        entries.extend(_scan_file(file, min_lines, min_nodes))
    return entries


def _files_for_paths(paths: Sequence[str], exclude_patterns: Sequence[str]) -> list[str]:
    all_excludes = [*_DEFAULT_EXCLUDE_PATTERNS, *exclude_patterns]
    seen: set[str] = set()
    files: list[str] = []

    def add(path: str) -> None:
        path = _to_slash(path)
        if path not in seen and not _is_excluded(path, all_excludes):
            seen.add(path)
            files.append(path)

    for path in paths:
        if not os.path.exists(path):
            continue
        if os.path.isfile(path):
            if _source_file(path):
                add(path)
            continue
        if not os.path.isdir(path):
            continue

        for root, dirs, names in os.walk(path, onerror=_raise_os_error):
            dirs[:] = sorted(
                dirname
                for dirname in dirs
                if not _skip_directory(root, dirname, all_excludes)
            )
            for name in sorted(names):
                file = os.path.join(root, name)
                if _source_file(file):
                    add(file)

    files.sort()
    return files


def _raise_os_error(error: OSError) -> None:
    raise error


def _source_file(path: str) -> bool:
    return path.endswith(".py")


def _skip_directory(root: str, dirname: str, exclude_patterns: Sequence[str]) -> bool:
    if dirname in _SKIP_DIRS or dirname.endswith(".egg-info"):
        return True
    return _is_excluded(os.path.join(root, dirname), exclude_patterns)


def _is_excluded(path: str, patterns: Sequence[str]) -> bool:
    normalized = _to_slash(path).rstrip("/")
    basename = normalized.rsplit("/", 1)[-1]
    components = normalized.split("/")
    for raw_pattern in patterns:
        pattern = _to_slash(raw_pattern).strip()
        if not pattern:
            continue
        directory_pattern = pattern.endswith("/")
        pattern = pattern.rstrip("/")
        if directory_pattern and "/" not in pattern and pattern in components:
            return True
        if fnmatch.fnmatch(normalized, pattern) or fnmatch.fnmatch(basename, pattern):
            return True
        if "/" not in pattern and pattern in components:
            return True
        if "/" in pattern and (
            normalized == pattern
            or normalized.startswith(pattern + "/")
            or f"/{pattern}/" in f"/{normalized}/"
        ):
            return True
    return False


def _scan_file(path: str, min_lines: int, min_nodes: int) -> list[_Entry]:
    with tokenize.open(path) as file:
        text = file.read()
    tree = ast.parse(text, filename=path, type_comments=True)
    pragmas = _scan_pragmas(text, tree)
    if pragmas.file_ignore:
        return []

    functions = list(_candidate_functions(tree))
    ignored_ranges = [
        _function_range(function)
        for function, _, _ in functions
        if _function_ignored(function, pragmas)
    ]

    entries: list[_Entry] = []
    for function, is_method, qualname in functions:
        start, end = _function_range(function)
        if _range_ignored(start, end, ignored_ranges):
            continue
        normalized = _normalize_function(function, is_method)
        nodes = _node_count(normalized)
        if end - start + 1 < min_lines or nodes < min_nodes:
            continue
        entries.append(
            _Entry(
                file=path,
                start_line=start,
                end_line=end,
                qualname=qualname,
                nodes=nodes,
                fingerprints=frozenset(_fingerprints(normalized)),
            )
        )
    return entries


def _scan_pragmas(text: str, tree: ast.Module) -> _Pragmas:
    ignore_lines: set[int] = set()
    file_ignore = False
    tokens = tokenize.generate_tokens(io.StringIO(text).readline)
    for token in tokens:
        if token.type != tokenize.COMMENT:
            continue
        match = _DRY4PYTHON_PRAGMA.search(token.string)
        if match is None:
            continue
        directive = match.group(1)
        if directive == "ignore-file":
            file_ignore = True
        if directive == "ignore" or directive == "ignore-file":
            ignore_lines.add(token.start[0])

    first_statement_line = min((_start_statement_line(statement) for statement in tree.body), default=10**9)
    if any(line < first_statement_line for line in ignore_lines):
        file_ignore = True
    return _Pragmas(file_ignore=file_ignore, ignore_lines=frozenset(ignore_lines))


def _start_statement_line(statement: ast.stmt) -> int:
    lines = [statement.lineno]
    decorator_list = getattr(statement, "decorator_list", [])
    lines.extend(decorator.lineno for decorator in decorator_list)
    return min(lines)


def _function_ignored(function: ast.FunctionDef | ast.AsyncFunctionDef, pragmas: _Pragmas) -> bool:
    start = _start_line(function)
    definition_lines = set(range(max(1, start - 1), function.lineno + 1))
    return bool(definition_lines & pragmas.ignore_lines)


def _function_range(function: ast.FunctionDef | ast.AsyncFunctionDef) -> tuple[int, int]:
    return _start_line(function), getattr(function, "end_lineno", None) or function.lineno


def _range_ignored(start: int, end: int, ignored_ranges: Sequence[tuple[int, int]]) -> bool:
    return any(start >= ignored_start and end <= ignored_end for ignored_start, ignored_end in ignored_ranges)


def _candidate_functions(tree: ast.Module) -> Iterable[tuple[ast.FunctionDef | ast.AsyncFunctionDef, bool, str]]:
    yield from _walk_candidate_body(tree.body, (), False)


def _walk_candidate_body(
    statements: Sequence[ast.stmt],
    prefix: tuple[str, ...],
    in_class_namespace: bool,
) -> Iterable[tuple[ast.FunctionDef | ast.AsyncFunctionDef, bool, str]]:
    for statement in _strip_docstring(statements):
        if isinstance(statement, (ast.FunctionDef, ast.AsyncFunctionDef)):
            qualname_parts = (*prefix, statement.name)
            yield statement, in_class_namespace, ".".join(qualname_parts)
            yield from _walk_candidate_body(statement.body, qualname_parts, False)
        elif isinstance(statement, ast.ClassDef):
            yield from _walk_candidate_body(statement.body, (*prefix, statement.name), True)
        else:
            for child_body in _child_statement_bodies(statement):
                yield from _walk_candidate_body(child_body, prefix, in_class_namespace)


def _child_statement_bodies(statement: ast.stmt) -> Iterable[Sequence[ast.stmt]]:
    for field, value in ast.iter_fields(statement):
        if field in {"body", "orelse", "finalbody"} and isinstance(value, list):
            if all(isinstance(item, ast.stmt) for item in value):
                yield value
        elif field == "handlers" and isinstance(value, list):
            for handler in value:
                if isinstance(handler, ast.ExceptHandler):
                    yield handler.body
        elif field == "cases" and isinstance(value, list):
            for match_case in value:
                if isinstance(match_case, ast.match_case):
                    yield match_case.body


def _start_line(function: ast.FunctionDef | ast.AsyncFunctionDef) -> int:
    lines = [function.lineno]
    lines.extend(decorator.lineno for decorator in function.decorator_list)
    return min(lines)


def _strip_docstring(statements: Sequence[ast.stmt]) -> Sequence[ast.stmt]:
    if statements and _is_docstring_statement(statements[0]):
        return statements[1:]
    return statements


def _is_docstring_statement(statement: ast.stmt) -> bool:
    return (
        isinstance(statement, ast.Expr)
        and isinstance(statement.value, ast.Constant)
        and isinstance(statement.value.value, str)
    )


def _normalize_function(function: ast.FunctionDef | ast.AsyncFunctionDef, is_method: bool) -> _Node:
    prefix = "async-" if isinstance(function, ast.AsyncFunctionDef) else ""
    kind = "method" if is_method else "func"
    children = [
        _normalize_arguments(function.args),
        _normalize_optional("returns", function.returns),
        _normalize_list("decorators", _expr_nodes(function.decorator_list)),
        _normalize_type_params(function),
        _normalize_list("body", _stmt_nodes(_strip_docstring(function.body))),
    ]
    return _Node(prefix + kind, tuple(children))


def _normalize_arguments(arguments: ast.arguments) -> _Node:
    children = [
        _normalize_list("posonly", [_normalize_arg(arg) for arg in arguments.posonlyargs]),
        _normalize_list("args", [_normalize_arg(arg) for arg in arguments.args]),
        _normalize_optional_arg("vararg", arguments.vararg),
        _normalize_list("kwonly", [_normalize_arg(arg) for arg in arguments.kwonlyargs]),
        _normalize_optional_arg("kwarg", arguments.kwarg),
        _normalize_list("defaults", _expr_nodes(arguments.defaults)),
        _normalize_list("kw-defaults", [_normalize_node(default) for default in arguments.kw_defaults]),
    ]
    return _Node("params", tuple(children))


def _normalize_optional_arg(tag: str, arg: ast.arg | None) -> _Node:
    return _normalize_optional(tag, arg, _normalize_arg)


def _normalize_arg(arg: ast.arg) -> _Node:
    children = [_normalize_optional("annotation", arg.annotation)]
    if arg.type_comment is not None:
        children.append(_Node("type-comment"))
    return _Node("arg", tuple(children))


def _normalize_type_params(node: ast.AST) -> _Node:
    type_params = getattr(node, "type_params", [])
    return _normalize_list("type-params", [_normalize_node(param) for param in type_params])


def _normalize_node(node: ast.AST | None) -> _Node:
    if node is None:
        return _Node("nil")

    if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
        return _normalize_function(node, False)
    if isinstance(node, ast.ClassDef):
        children = [
            _normalize_list("bases", _expr_nodes(node.bases)),
            _normalize_list("keywords", [_normalize_keyword(keyword) for keyword in node.keywords]),
            _normalize_list("decorators", _expr_nodes(node.decorator_list)),
            _normalize_type_params(node),
            _normalize_list("body", _stmt_nodes(_strip_docstring(node.body))),
        ]
        return _Node("class", tuple(children))

    if isinstance(node, ast.Return):
        return _Node("return", (_normalize_node(node.value),))
    if isinstance(node, ast.Delete):
        return _normalize_list("delete", _expr_nodes(node.targets))
    if isinstance(node, ast.Assign):
        children = [
            _normalize_list("targets", _expr_nodes(node.targets)),
            _normalize_node(node.value),
        ]
        if node.type_comment is not None:
            children.append(_Node("type-comment"))
        return _Node("assign", tuple(children))
    if isinstance(node, ast.AnnAssign):
        return _Node(
            f"ann-assign/{'simple' if node.simple else 'complex'}",
            (_normalize_node(node.target), _normalize_node(node.annotation), _normalize_node(node.value)),
        )
    if isinstance(node, ast.AugAssign):
        return _Node(
            f"aug-assign/{_op_name(node.op)}",
            (_normalize_node(node.target), _normalize_node(node.value)),
        )
    if isinstance(node, ast.For):
        children = [
            _normalize_node(node.target),
            _normalize_node(node.iter),
            _normalize_list("body", _stmt_nodes(node.body)),
            _normalize_list("orelse", _stmt_nodes(node.orelse)),
        ]
        if node.type_comment is not None:
            children.append(_Node("type-comment"))
        return _Node("for", tuple(children))
    if isinstance(node, ast.AsyncFor):
        children = [
            _normalize_node(node.target),
            _normalize_node(node.iter),
            _normalize_list("body", _stmt_nodes(node.body)),
            _normalize_list("orelse", _stmt_nodes(node.orelse)),
        ]
        if node.type_comment is not None:
            children.append(_Node("type-comment"))
        return _Node("async-for", tuple(children))
    if isinstance(node, ast.While):
        return _Node(
            "while",
            (
                _normalize_node(node.test),
                _normalize_list("body", _stmt_nodes(node.body)),
                _normalize_list("orelse", _stmt_nodes(node.orelse)),
            ),
        )
    if isinstance(node, ast.If):
        return _Node(
            "if",
            (
                _normalize_node(node.test),
                _normalize_list("body", _stmt_nodes(node.body)),
                _normalize_list("orelse", _stmt_nodes(node.orelse)),
            ),
        )
    if isinstance(node, ast.With):
        children = [
            _normalize_list("items", [_normalize_with_item(item) for item in node.items]),
            _normalize_list("body", _stmt_nodes(node.body)),
        ]
        if node.type_comment is not None:
            children.append(_Node("type-comment"))
        return _Node("with", tuple(children))
    if isinstance(node, ast.AsyncWith):
        children = [
            _normalize_list("items", [_normalize_with_item(item) for item in node.items]),
            _normalize_list("body", _stmt_nodes(node.body)),
        ]
        if node.type_comment is not None:
            children.append(_Node("type-comment"))
        return _Node("async-with", tuple(children))
    if isinstance(node, ast.Match):
        return _Node(
            "match",
            (_normalize_node(node.subject), _normalize_list("cases", [_normalize_node(case) for case in node.cases])),
        )
    if isinstance(node, ast.Raise):
        return _Node("raise", (_normalize_node(node.exc), _normalize_node(node.cause)))
    if isinstance(node, ast.Try):
        return _normalize_try("try", node)
    try_star = getattr(ast, "TryStar", None)
    if try_star is not None and isinstance(node, try_star):
        return _normalize_try("try-star", node)
    if isinstance(node, ast.Assert):
        return _Node("assert", (_normalize_node(node.test), _normalize_node(node.msg)))
    if isinstance(node, ast.Import):
        return _normalize_list("import", [_normalize_alias(alias) for alias in node.names])
    if isinstance(node, ast.ImportFrom):
        children = [_Node(f"level/{node.level}"), _normalize_list("aliases", [_normalize_alias(alias) for alias in node.names])]
        return _Node("import-from", tuple(children))
    if isinstance(node, ast.Global):
        return _Node("global", tuple(_Node("ident") for _ in node.names))
    if isinstance(node, ast.Nonlocal):
        return _Node("nonlocal", tuple(_Node("ident") for _ in node.names))
    if isinstance(node, ast.Expr):
        return _Node("expr-stmt", (_normalize_node(node.value),))
    if isinstance(node, ast.Pass):
        return _Node("pass")
    if isinstance(node, ast.Break):
        return _Node("break")
    if isinstance(node, ast.Continue):
        return _Node("continue")

    if isinstance(node, ast.BoolOp):
        return _Node(f"bool/{_op_name(node.op)}", tuple(_expr_nodes(node.values)))
    if isinstance(node, ast.NamedExpr):
        return _Node("named-expr", (_normalize_node(node.target), _normalize_node(node.value)))
    if isinstance(node, ast.BinOp):
        return _Node(
            f"binary/{_op_name(node.op)}",
            (_normalize_node(node.left), _normalize_node(node.right)),
        )
    if isinstance(node, ast.UnaryOp):
        return _Node(f"unary/{_op_name(node.op)}", (_normalize_node(node.operand),))
    if isinstance(node, ast.Lambda):
        return _Node("lambda", (_normalize_arguments(node.args), _normalize_node(node.body)))
    if isinstance(node, ast.IfExp):
        return _Node(
            "if-exp",
            (_normalize_node(node.test), _normalize_node(node.body), _normalize_node(node.orelse)),
        )
    if isinstance(node, ast.Dict):
        children = [
            _Node("item", (_normalize_node(key), _normalize_node(value)))
            for key, value in zip(node.keys, node.values)
        ]
        return _normalize_list("dict", children)
    if isinstance(node, ast.Set):
        return _normalize_list("set", _expr_nodes(node.elts))
    if isinstance(node, ast.ListComp):
        return _Node("list-comp", (_normalize_node(node.elt), *_comprehension_nodes(node.generators)))
    if isinstance(node, ast.SetComp):
        return _Node("set-comp", (_normalize_node(node.elt), *_comprehension_nodes(node.generators)))
    if isinstance(node, ast.DictComp):
        return _Node(
            "dict-comp",
            (_normalize_node(node.key), _normalize_node(node.value), *_comprehension_nodes(node.generators)),
        )
    if isinstance(node, ast.GeneratorExp):
        return _Node("generator", (_normalize_node(node.elt), *_comprehension_nodes(node.generators)))
    if isinstance(node, ast.Await):
        return _Node("await", (_normalize_node(node.value),))
    if isinstance(node, ast.Yield):
        return _Node("yield", (_normalize_node(node.value),))
    if isinstance(node, ast.YieldFrom):
        return _Node("yield-from", (_normalize_node(node.value),))
    if isinstance(node, ast.Compare):
        children = [_normalize_node(node.left)]
        children.extend(_Node(f"op/{_op_name(op)}") for op in node.ops)
        children.extend(_expr_nodes(node.comparators))
        return _Node("compare", tuple(children))
    if isinstance(node, ast.Call):
        children = [
            _normalize_callee(node.func),
            _normalize_list("args", _expr_nodes(node.args)),
            _normalize_list("keywords", [_normalize_keyword(keyword) for keyword in node.keywords]),
        ]
        return _Node("call", tuple(children))
    if isinstance(node, ast.FormattedValue):
        return _Node(
            f"formatted/{node.conversion}",
            (_normalize_node(node.value), _normalize_node(node.format_spec)),
        )
    if isinstance(node, ast.JoinedStr):
        return _normalize_list("joined-str", _expr_nodes(node.values))
    if isinstance(node, ast.Constant):
        return _normalize_constant(node.value)
    if isinstance(node, ast.Attribute):
        return _Node("attribute", (_normalize_node(node.value), _Node("member")))
    if isinstance(node, ast.Subscript):
        return _Node("subscript", (_normalize_node(node.value), _normalize_node(node.slice)))
    if isinstance(node, ast.Starred):
        return _Node("starred", (_normalize_node(node.value),))
    if isinstance(node, ast.Name):
        return _Node("ident")
    if isinstance(node, ast.List):
        return _normalize_list("list", _expr_nodes(node.elts))
    if isinstance(node, ast.Tuple):
        return _normalize_list("tuple", _expr_nodes(node.elts))
    if isinstance(node, ast.Slice):
        return _Node("slice", (_normalize_node(node.lower), _normalize_node(node.upper), _normalize_node(node.step)))

    if isinstance(node, ast.keyword):
        return _normalize_keyword(node)
    if isinstance(node, ast.arg):
        return _normalize_arg(node)
    if isinstance(node, ast.alias):
        return _normalize_alias(node)
    if isinstance(node, ast.comprehension):
        return _normalize_comprehension(node)
    if isinstance(node, ast.ExceptHandler):
        tag = "except/name" if node.name else "except"
        return _Node(tag, (_normalize_node(node.type), _normalize_list("body", _stmt_nodes(node.body))))
    if isinstance(node, ast.withitem):
        return _normalize_with_item(node)
    if isinstance(node, ast.match_case):
        return _Node(
            "case",
            (_normalize_node(node.pattern), _normalize_node(node.guard), _normalize_list("body", _stmt_nodes(node.body))),
        )

    if isinstance(node, ast.MatchValue):
        return _Node("match-value", (_normalize_node(node.value),))
    if isinstance(node, ast.MatchSingleton):
        return _Node("match-singleton", (_normalize_constant(node.value),))
    if isinstance(node, ast.MatchSequence):
        return _normalize_list("match-sequence", [_normalize_node(pattern) for pattern in node.patterns])
    if isinstance(node, ast.MatchMapping):
        children = [
            _normalize_list("keys", _expr_nodes(node.keys)),
            _normalize_list("patterns", [_normalize_node(pattern) for pattern in node.patterns]),
        ]
        if node.rest is not None:
            children.append(_Node("rest"))
        return _Node("match-mapping", tuple(children))
    if isinstance(node, ast.MatchClass):
        return _Node(
            "match-class",
            (
                _normalize_node(node.cls),
                _normalize_list("patterns", [_normalize_node(pattern) for pattern in node.patterns]),
                _normalize_list("kwd-patterns", [_normalize_node(pattern) for pattern in node.kwd_patterns]),
            ),
        )
    if isinstance(node, ast.MatchStar):
        return _Node("match-star/name" if node.name is not None else "match-star")
    if isinstance(node, ast.MatchAs):
        tag = "match-as/name" if node.name is not None else "match-as"
        return _Node(tag, (_normalize_node(node.pattern),))
    if isinstance(node, ast.MatchOr):
        return _normalize_list("match-or", [_normalize_node(pattern) for pattern in node.patterns])

    return _Node(_node_name(node))


def _normalize_optional(tag: str, node: Any, normalizer: Callable[[Any], _Node] = _normalize_node) -> _Node:
    if node is None:
        return _Node(tag)
    return _Node(tag, (normalizer(node),))


def _normalize_list(tag: str, children: Iterable[_Node]) -> _Node:
    return _Node(tag, tuple(children))


def _normalize_try(tag: str, node: ast.Try) -> _Node:
    return _Node(
        tag,
        (
            _normalize_list("body", _stmt_nodes(node.body)),
            _normalize_list("handlers", [_normalize_node(handler) for handler in node.handlers]),
            _normalize_list("orelse", _stmt_nodes(node.orelse)),
            _normalize_list("finalbody", _stmt_nodes(node.finalbody)),
        ),
    )


def _normalize_with_item(item: ast.withitem) -> _Node:
    return _Node("with-item", (_normalize_node(item.context_expr), _normalize_node(item.optional_vars)))


def _normalize_keyword(keyword: ast.keyword) -> _Node:
    tag = "keyword/unpack" if keyword.arg is None else "keyword"
    return _Node(tag, (_normalize_node(keyword.value),))


def _normalize_alias(alias: ast.alias) -> _Node:
    return _Node("alias/as" if alias.asname is not None else "alias")


def _normalize_comprehension(comprehension: ast.comprehension) -> _Node:
    tag = "comprehension/async" if comprehension.is_async else "comprehension"
    return _Node(
        tag,
        (
            _normalize_node(comprehension.target),
            _normalize_node(comprehension.iter),
            _normalize_list("ifs", _expr_nodes(comprehension.ifs)),
        ),
    )


def _normalize_constant(value: object) -> _Node:
    if value is True:
        return _Node("literal/true")
    if value is False:
        return _Node("literal/false")
    if value is None:
        return _Node("literal/none")
    if value is Ellipsis:
        return _Node("literal/ellipsis")
    return _Node(f"literal/{type(value).__name__.lower()}")


def _normalize_callee(expr: ast.expr) -> _Node:
    if isinstance(expr, ast.Name):
        return _Node("callee")
    if isinstance(expr, ast.Attribute):
        return _Node("attribute-callee", (_normalize_node(expr.value), _Node("member")))
    return _normalize_node(expr)


def _stmt_nodes(statements: Sequence[ast.stmt]) -> list[_Node]:
    return [_normalize_node(statement) for statement in statements]


def _expr_nodes(expressions: Sequence[ast.AST | None]) -> list[_Node]:
    return [_normalize_node(expression) for expression in expressions]


def _comprehension_nodes(comprehensions: Sequence[ast.comprehension]) -> tuple[_Node, ...]:
    return tuple(_normalize_comprehension(comprehension) for comprehension in comprehensions)


def _node_count(node: _Node) -> int:
    return 1 + sum(_node_count(child) for child in node.children)


def _fingerprints(node: _Node) -> set[str]:
    out: set[str] = set()

    def walk(current: _Node) -> None:
        out.add(_serialize(current))
        for child in current.children:
            walk(child)

    walk(node)
    return out


def _serialize(node: _Node) -> str:
    if not node.children:
        return f"({node.tag})"
    children = " ".join(_serialize(child) for child in node.children)
    return f"({node.tag} {children})"


def _similarity(left: _Entry, right: _Entry) -> float:
    intersection = len(left.fingerprints & right.fingerprints)
    union = len(left.fingerprints | right.fingerprints)
    if union == 0:
        return 0.0
    return intersection / union


def _location(entry: _Entry) -> Location:
    return Location(
        file=entry.file,
        start_line=entry.start_line,
        end_line=entry.end_line,
        qualname=entry.qualname,
    )


def _line_range(location: Location) -> str:
    suffix = f" {location.qualname}" if location.qualname else ""
    return f"{location.file}:{location.start_line}-{location.end_line}{suffix}"


def _to_slash(path: str) -> str:
    return path.replace(os.sep, "/").replace("\\", "/")


def _op_name(op: ast.AST) -> str:
    return _node_name(op)


def _node_name(node: ast.AST) -> str:
    return _CAMEL_BOUNDARY.sub("-", node.__class__.__name__).lower().replace("_", "-")
