from __future__ import annotations

import sys

from . import dry


def main(argv: list[str] | None = None) -> int:
    args = sys.argv[1:] if argv is None else argv
    try:
        options = dry.parse_args(args)
    except ValueError as error:
        print(error, file=sys.stderr)
        print(file=sys.stderr)
        print(dry.USAGE, file=sys.stderr)
        return 2

    if options.help:
        print(dry.USAGE)
        return 0

    try:
        candidates = dry.find_duplicates(options)
    except OSError as error:
        print(error, file=sys.stderr)
        return 1
    except SyntaxError as error:
        print(error, file=sys.stderr)
        return 1

    if options.format == "text":
        print(dry.format_text(candidates), end="")
        return 0
    if options.format == "json":
        print(dry.format_json(candidates), end="")
        return 0

    print(f"unknown format: {options.format}", file=sys.stderr)
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
